#include <iostream>
#include <fstream>
#include <cstring> //Para copiar la cadena y strtok

//------------PROGRAMA 9: Busqueda Binaria----------------
//----------CORTAZAR DE LA CRUZ MANUEL GIOVANNI 2193001368----------
using namespace std;
struct Alumno
{

  string matricula;
  string primerApellido;
  string segundoApellido;
  string nombre;
};

void busquedaBinaria(Alumno[], string);

int main()
{

  Alumno alumnos[100];
  int nAlumnos = 0;
  int i = 0;
  string cadena;
  char cadenaArr[200];

  ifstream entrada("alumnos.txt"); //Se crea la uni�n al archivo

  while (!entrada.eof())
  {

    getline(entrada, cadena);          //Se lee la l�nea completa con espacios y separador
    strcpy(cadenaArr, cadena.c_str()); // strtok necesita char[] no string, por eso se convierte

    alumnos[i].matricula = strtok(cadenaArr, ",");  //El primer token
    alumnos[i].nombre = strtok(NULL, ",");          //El segundo token, NULL hace referencia a la misma cadena
    alumnos[i].primerApellido = strtok(NULL, ",");  //El tercer token
    alumnos[i].segundoApellido = strtok(NULL, ","); //El cuarto token

    i++;
    nAlumnos++;
  }
  entrada.close(); //Se cierra el archivo

  //Se imprime el arreglo de alumnos para ver que est�n los datos
  for (int j = 0; j < nAlumnos; j++)
  {
    cout << alumnos[j].matricula << "---" << alumnos[j].nombre << "---"
         << alumnos[j].primerApellido << "---" << alumnos[j].segundoApellido << endl;
  }
  cout << endl;
  //---------------------------INSERCION DE LA BUSQUEDA BINARIA--------------------------------

  cout << "------------PROGRAMA 9: Busqueda Binaria----------------" << endl;
  cout << "----------CORTAZAR DE LA CRUZ MANUEL GIOVANNI 2193001368----------" << endl;
  cout << "solicitar la matricula de un alumno para buscarla" << endl;
  cout << "utilizando busqueda binaria decir si el alumno se encuentra o no" << endl;
  cout << endl;

  string buscado = "";
  int primero = 0,
      ultimo = nAlumnos - 1,
      medio = 0;
  bool encontrado = false;
  cout << "Ingresa la matricula de un alumno a buscar" << endl;
  cin >> buscado;

  while (primero <= ultimo && !encontrado)
  {
    medio = (primero + ultimo) / 2;
    int valor = alumnos[medio].matricula.compare(buscado);
    if (valor == 0)
    {
      encontrado = true;
    }
    else if (valor > 0)
    {
      ultimo = medio - 1;
    }
    else
    {
      primero = medio + 1;
    }
  }
  if (encontrado == true)
  {
    cout << "El alumno existe" << endl;
    cout << "Informacion de alumno:" << endl;
    cout << alumnos[medio].matricula << "---" << alumnos[medio].nombre << "---"
         << alumnos[medio].primerApellido << "---" << alumnos[medio].segundoApellido << endl;
  }
  else
  {
    cout << "El alumno no existe" << endl;
  }
}