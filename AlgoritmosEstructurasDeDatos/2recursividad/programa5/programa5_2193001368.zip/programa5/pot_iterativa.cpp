
#include "pot_iterativa.h"
double potencia_i(int a , int b){
    if (b == 0)
    {
        return 1;
    }

    int c = 1, d = 0;
    while (b>0)
    {
        d = a;
        a = a * c;
        c = a;
        a = d;
        b--;
    }
    return c;
}
