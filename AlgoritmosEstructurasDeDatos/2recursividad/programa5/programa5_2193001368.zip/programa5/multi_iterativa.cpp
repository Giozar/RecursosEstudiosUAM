#include "multi_iterativa.h"
double multiplicacion_i(int a, int b){
    if (b<0)
    {
        b = -b;
        a = -a;
    }else if ((a == 0|| b == 0))
    {
        return 0;
    }

    int c = a;
    for (b+=-1 ; b > 0; b--)
    {
        a += c;
    }
    return a ;
}
