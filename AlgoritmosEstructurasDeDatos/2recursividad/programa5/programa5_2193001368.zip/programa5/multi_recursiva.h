
#ifndef M_R
#define M_R

double multiplicacion(int a, int b);

#endif //M_R

