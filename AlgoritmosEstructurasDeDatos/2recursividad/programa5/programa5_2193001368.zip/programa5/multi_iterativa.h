#ifndef M_I
#define M_I

double multiplicacion_i(int a, int b);

#endif //M_I

