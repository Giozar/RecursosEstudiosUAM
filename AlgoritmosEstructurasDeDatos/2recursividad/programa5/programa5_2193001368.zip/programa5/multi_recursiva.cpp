
#include "multi_recursiva.h"
double multiplicacion(int a, int b){
    if (b == 0)
    {
        return 0;
    }
    if (b<0)
    {
        b = -b;
        a = -a;
        return a + multiplicacion(a,b-1);
    }else
    {
        return a + multiplicacion(a,b-1);
    }
}
