#ifndef P_R
#define P_R
double potencia(int a, int b);
#endif // P_R

