#include "pot_recursiva.h"
double potencia(int a, int b){
    if (b==0)
    {
        return 1;
    }else
    {
        return a * potencia(a,b-1);
    }
}
