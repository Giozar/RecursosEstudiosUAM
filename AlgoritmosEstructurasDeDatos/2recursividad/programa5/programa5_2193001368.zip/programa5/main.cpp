#include <iostream>
#include "multi_recursiva.h"
#include "multi_iterativa.h"
#include "pot_recursiva.h"
#include "pot_iterativa.h"
using namespace std;

int main()
{
    double multi;
    double multi_i;
    double pot;
    double pot2;
    int a,b,c,d;
    cout<<"CORTAZAR DE LA CRUZ MANUEL GIOVANNI Matricula:2193001368"<<endl<<endl;

    cout<<"-------------Dados dos numeros (a,b) calcule su multiplicacion-----------------"<<endl<<endl;
    cout<<"ingrese a"<<endl;
    cin>>a;
    cout<<"ingrese b"<<endl;
    cin>>b;

    multi = multiplicacion(a,b);
    cout <<"(funcion recursiva)La multiplicacion de "<<a<<" por "<<b<<" es "<<multi <<endl<<endl;

    multi_i = multiplicacion_i(a,b);
    cout <<"(funcion iterativa)La multiplicacion de "<<a<<" por "<<b<<" es "<<multi_i <<endl<<endl;

    cout<<"------------Dada una base y un exponente (b,e), calcule b^e-------------"<<endl;
    cout<<"ingrese una base"<<endl;
    cin>>a;
    cout<<"ingrese un exponente"<<endl;
    cin>>b;

    d = b;

    if(b<=0){
            b = -b;

            if(a==0){
                cout <<"(funcion recursiva)La potencia de "<<a <<" ^ "<<d << " es indefinido"<<endl;

                cout <<"(funcion iterativa)La potencia de "<<a <<" ^ "<<d << " es indefinido"<<endl;

                return 0;
            }

            pot = potencia(a,b);
            cout <<"(funcion recursiva)La potencia de "<<a <<" ^ "<<d << " es 1/"<<pot <<endl;

            pot2 = potencia_i(a,b);
            cout <<"(funcion iterativa)La potencia de "<<a <<" ^ "<<d << " es 1/"<<pot2 <<endl;

            return 0;
    }



    pot = potencia(a,b);
    cout <<"(funcion recursiva)La potencia de "<<a <<" ^ "<<b << " es "<<pot <<endl;

    pot2 = potencia_i(a,b);
    cout <<"(funcion iterativa)La potencia de "<<a <<" ^ "<<b << " es "<<pot2 <<endl;

    return 0;
}
