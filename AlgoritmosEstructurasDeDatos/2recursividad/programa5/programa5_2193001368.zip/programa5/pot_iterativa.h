#ifndef P_I
#define P_I
double potencia_i(int a, int b);
#endif // P_I

