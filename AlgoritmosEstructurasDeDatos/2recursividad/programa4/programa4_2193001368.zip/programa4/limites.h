
#ifndef LIMITES_H
#define LIMITES_H

struct Limites
{
    int limite_superior;
    int limite_inferior;
};


#endif //LIMITES_H
