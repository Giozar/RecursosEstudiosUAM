#include "funcion_sumatoria.h"
double polinomio(int a){
    if (a < 0)
    {
        return 0;
    }else
    {
        return ((a*a*a)+(3*a*a)-(2*a)+6)+polinomio(a-1);
    }
}
