#include <iostream>
#include "sumatoria.h"
#include "funcion_sumatoria.h"
using namespace std;

int main()
{
    //programa (A)
    cout<<"CORTAZAR DE LA CRUZ MANUEL GIOVANNI"<<endl;
    cout<<"Matricula: 2193001368"<<endl;
    cout<<"Programa 4"<<endl;

    int a,b;
    cout<<"A) Calcular la sumatoria desde un limite inferior hasta un limite superior de manera recursiva."<<endl<<endl;
    cout<<"ingrese el limite inferior de la sumatoria"<<endl;
    cin>>a;
    cout<<"ingrese el limite superior de la sumatoria"<<endl;
    cin>>b;
    while(b<a){
        cout<<"ingrese un limite superior al anterior"<<endl;
        cin>>b;
    }
    double suma;
    suma = sumatoria1(b,a);//<----aqui va el limite superior

    cout <<"la sumatoria desde el limite inferior "<<a<<" hasta el limite superior "<<b<<" es: "<<suma <<endl<<endl<<endl;

    //programa (B)
    cout<<"B) (iniciando en 0)la suma de los primeros n numeros evaluados en la funcion n^3 + 3n^2 - 2n +6"<<endl<<endl;
    int a2;
    double poli;
    cout<<"ingrese el limite de la sumatoria"<<endl;
    cin>>a2;
    poli = polinomio(a2);
    cout <<"la suma es "<<poli <<endl;
    if (poli == 0)
    {
        cout<<"Dado que el limite inferior de la suma es mayor que el limite superior de la suma, es una suma vacia y su valor se define como cero"<<endl;
    }

    return 0;
}
