#ifndef L_H
#define L_H

double sumatoria1(int a, int b);

#endif //L_H
