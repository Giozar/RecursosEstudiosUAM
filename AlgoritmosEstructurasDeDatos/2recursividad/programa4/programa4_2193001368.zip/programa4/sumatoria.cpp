//-----------MATRICULA: 2193001368-----------------------------------------
//-------------------------MANUEL GIOVANNI CORTAZAR DE LA CRUZ-----------------
//------------------TAREA: PROGRAMA 3---------------------------
#include "sumatoria.h"
double sumatoria1(int b, int a){
    if (b == a)//<--aqui va el limite inferior
    {
        return b;
    }else
    {
        return b + sumatoria1(b-1,a);
    }
}
