#ifndef F_H
#define F_H

double polinomio(int a);

#endif //F_H
