#ifndef SUMAFRACCION_H
#define SUMAFRACCION_H
#include "fraccion.h"

Fraccion sumaFracciones(Fraccion, Fraccion);

#endif //MF_H