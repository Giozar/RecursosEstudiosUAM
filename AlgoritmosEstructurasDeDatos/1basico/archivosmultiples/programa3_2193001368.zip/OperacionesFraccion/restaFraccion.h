#ifndef RESTAFRACCION_H
#define RESTAFRACCION_H
#include "fraccion.h"

Fraccion restaFracciones(Fraccion, Fraccion);

#endif //MF_H
