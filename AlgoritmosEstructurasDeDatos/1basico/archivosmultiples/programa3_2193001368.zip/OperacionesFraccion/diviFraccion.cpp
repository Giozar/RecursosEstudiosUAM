//-----------MATRICULA: 2193001368-----------------------------------------
//-------------------------MANUEL GIOVANNI CORTAZAR DE LA CRUZ-----------------
//------------------TAREA: PROGRAMA 3---------------------------
#include "diviFraccion.h"
Fraccion diviFracciones(Fraccion a, Fraccion b){
    Fraccion resultado;
    resultado.numerador = a.numerador * b.denominador;
    resultado.denominador = a.denominador * b.numerador;
    if (resultado.denominador == 0)
    {
        resultado.tipo = 4;
        return resultado;
    }
    
    if (resultado.numerador<resultado.denominador)
    {
        resultado.tipo = 1;
    }else if(resultado.numerador>=resultado.denominador)
    {
        if (resultado.numerador%resultado.denominador==0)
        {
            resultado.tipo = 3;
            return resultado;
        }
        resultado.tipo = 2;
    }
    return resultado;
}

