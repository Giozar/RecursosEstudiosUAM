#ifndef DF_H
#define DF_H
#include "fraccion.h"

Fraccion diviFracciones(Fraccion, Fraccion);

#endif //MF_H
