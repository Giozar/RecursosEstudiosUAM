//-----------MATRICULA: 2193001368-----------------------------------------
//-------------------------MANUEL GIOVANNI CORTAZAR DE LA CRUZ-----------------
//------------------TAREA: PROGRAMA 3---------------------------
#include <iostream>
#include "multiplicaFraccion.h"
#include "sumaFraccion.h"
#include "restaFraccion.h"
#include "diviFraccion.h"
using namespace std;
int main()
{

    Fraccion fraccionA;
    Fraccion fraccionB;
    Fraccion resmulti;
    Fraccion ressuma;
    Fraccion reresta;
    Fraccion resdivi;

    //codigo estatico--->
    fraccionA.numerador = 5;
    fraccionA.denominador = 8;
    fraccionB.numerador = 4;
    fraccionB.denominador = 6;

    cout<<"Fraccion A: "<<fraccionA.numerador<<"/"<<fraccionA.denominador<<endl;
    cout<<"Fraccion B: "<<fraccionB.numerador<<"/"<<fraccionB.denominador<<endl;
    //habilite lo demas para hacer el codigo dinamico--->


//codigo para que el usuario ingrese los datos
//habilite esta parte de codigo y borre lo de arriba indicado

/*     cout<<"Ingresa el numerador de A"<<endl;
    cin>>fraccionA.numerador;
    do
    {
        cout<<"Ingresa el denominador de A (diferente de 0)"<<endl;
        cin>>fraccionA.denominador;
    } while (fraccionA.denominador==0);
    
    
    cout<<"Ingresa el numerador de B"<<endl;
    cin>>fraccionB.numerador;
    do
    {
        cout<<"Ingresa el denominador de B (diferente de 0)"<<endl;
        cin>>fraccionB.denominador;
    } while (fraccionB.denominador==0); */

    resmulti = multiplicaFracciones(fraccionA,fraccionB);

    ressuma = sumaFracciones(fraccionA,fraccionB);

    reresta = restaFracciones(fraccionA,fraccionB);

    resdivi = diviFracciones(fraccionA,fraccionB);

    cout<<"la multiplicacion es "<<resmulti.numerador<<"/"<<resmulti.denominador<<" Es una fraccion ";
    if (resmulti.tipo == 1)
    {
        cout<<"propia"<<endl;
    }else if(resmulti.tipo == 2)
    {
        cout<<"impropia"<<endl;
    }else if(resmulti.tipo == 3)
    {
        cout<<"Entera"<<endl;
    }else if(resmulti.tipo == 4)
    {
        cout<<"erronea, el denominador es 0, no existe!!"<<endl;
    }
    
    
    
    

    cout<<"la suma es "<<ressuma.numerador<<"/"<<ressuma.denominador<<" Es una fraccion ";
    if (ressuma.tipo == 1)
    {
        cout<<"propia"<<endl;
    }else if(ressuma.tipo == 2)
    {
        cout<<"impropia"<<endl;
    }else if(ressuma.tipo == 3)
    {
        cout<<"Entera"<<endl;
    }else if(ressuma.tipo == 4)
    {
        cout<<"erronea, el denominador es 0, no existe!!"<<endl;
    }

    cout<<"la resta es "<<reresta.numerador<<"/"<<reresta.denominador<<" Es una fraccion ";
    if (reresta.tipo == 1)
    {
        cout<<"propia"<<endl;
    }else if(reresta.tipo == 2)
    {
        cout<<"impropia"<<endl;
    }else if(reresta.tipo == 3)
    {
        cout<<"Entera"<<endl;
    }else if(reresta.tipo == 4)
    {
        cout<<"erronea, el denominador es 0, no existe!!"<<endl;
    }

    cout<<"la division es "<<resdivi.numerador<<"/"<<resdivi.denominador<<" Es una fraccion ";
    if (resdivi.tipo == 1)
    {
        cout<<"propia"<<endl;
    }else if(resdivi.tipo == 2)
    {
        cout<<"impropia"<<endl;
    }else if(resdivi.tipo == 3)
    {
        cout<<"Entera"<<endl;
    }else if(resdivi.tipo == 4)
    {
        cout<<"erronea, el denominador es 0, no existe!!"<<endl;
    }


    return 0;

}
