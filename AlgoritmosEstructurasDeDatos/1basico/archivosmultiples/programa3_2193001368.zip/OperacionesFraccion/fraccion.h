#ifndef FRACCION_H
#define FRACCION_H

struct Fraccion
{
    int numerador;
    int denominador;
    int tipo;
};


#endif //FRACCION_H