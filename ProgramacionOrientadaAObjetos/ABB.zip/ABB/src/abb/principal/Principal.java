package abb.principal;

import java.util.Random;
import abb.clases.ArbolBinarioBusqueda;
import abb.clases.DatoProducto;
import abb.operaciones.OperacionesABB;

public class Principal {
	public static void main(String[] args) {
		int n = 20;
		
		Random r = new Random();
		ArbolBinarioBusqueda arbol = new ArbolBinarioBusqueda();
		OperacionesABB op = new OperacionesABB();
		
		System.out.println("\t** �rbol Binario de B�squeda **");
		System.out.println("\n~ �El �rbol est� vac�o?");
		System.out.println(op.vacio(arbol));
		
		System.out.println("\n*~ Se insertan n�meros aleatorios al �rbol y se determina si tiene n�meros repetidos");
		
		for(int i=0; i<n; ++i) {
			int id = r.nextInt(50) + 1;
			System.out.println("\n*N�mero "+(i+1)+" insertado: " +id);
			if(id<10) {
				DatoProducto dp = new DatoProducto(id, "COD00"+id);
				arbol.setRaiz(op.insertar(dp, arbol.getRaiz()));
				}else {
					DatoProducto db = new DatoProducto(id, "COD0"+id);
					arbol.setRaiz(op.insertar(db, arbol.getRaiz()));
					}
			
			System.out.println("~ Se imprime en Inorden");
			op.imprimirInOrden(arbol.getRaiz());
			System.out.println("===================");
			}
		
		System.out.println("\n*~ Se imprime el �rbol final generado con n�meros aleatorios en:\n");
		System.out.println(">PREORDEN");
		op.imprimirPreOrden(arbol.getRaiz());
		System.out.println();
		System.out.println(">INORDEN");
		op.imprimirInOrden(arbol.getRaiz());
		System.out.println();
		System.out.println(">POSTORDEN");
		op.imprimirPostOrden(arbol.getRaiz());
	}

}
