package abb.operaciones;

import abb.clases.ArbolBinarioBusqueda;
import abb.clases.DatoProducto;
import abb.clases.NodoBinario;

public class OperacionesABB {
	
	//M�todo para confirmar si el �rbol est� vac�o o no
	public boolean vacio(ArbolBinarioBusqueda a) {
		if(a.getRaiz() == null) {
			return true;
		}else {
			return false;
		}
	}
	
	//Insertar elementos
	public NodoBinario insertar(DatoProducto dato, NodoBinario t) {
		if(t == null) {
			t = new NodoBinario(dato, null, null);
		}else if(dato.getId()<t.getElemento().getId()) {
			t.setIzquierda(insertar(dato, t.getIzquierda()));
		}else if(dato.getId()>t.getElemento().getId()) {
			t.setDerecha(insertar(dato, t.getDerecha()));
		}else {
			System.out.println("-- El elemento ya existe");
		}
		return t;
	}
	
	//Recorrido en Preorden
	public void imprimirPreOrden(NodoBinario t) {
		if(t != null) {
			System.out.println(t.getElemento().toString()+" ");
			imprimirPreOrden(t.getIzquierda());
			imprimirPreOrden(t.getDerecha());
		}
	}
	
	//Recorrido en Inorden
	public void imprimirInOrden(NodoBinario t) {
		if(t != null) {
			imprimirInOrden(t.getIzquierda());
			System.out.println(t.getElemento().toString()+" ");
			imprimirInOrden(t.getDerecha());
		}
	}
	
	//Recorrido en Postorden
	public void imprimirPostOrden(NodoBinario t) {
		if(t != null) {
			imprimirPostOrden(t.getIzquierda());
			imprimirPostOrden(t.getDerecha());
			System.out.println(t.getElemento().toString());
		}
	}

}
