package abb.clases;

public class DatoProducto {
	
	private int id;
	private String codigo;
	
	public DatoProducto() {
		
	}
	
	public DatoProducto(int id, String c) {
		this.id = id;
		this.codigo = c;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}
	
	public String toString() {
		return  "C�digo: "+ this.codigo;
	}
}
