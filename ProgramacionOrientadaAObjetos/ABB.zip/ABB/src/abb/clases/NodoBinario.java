package abb.clases;

public class NodoBinario {
	
	private DatoProducto elemento;
	private NodoBinario izquierda;
	private NodoBinario derecha;
	
	public NodoBinario() {
		
	}
	
	public NodoBinario(DatoProducto p, NodoBinario izq, NodoBinario der) {
		this.elemento = p;
		this.izquierda = izq;
		this.derecha = der;
	}

	public DatoProducto getElemento() {
		return elemento;
	}

	public void setElemento(DatoProducto elemento) {
		this.elemento = elemento;
	}

	public NodoBinario getIzquierda() {
		return izquierda;
	}

	public void setIzquierda(NodoBinario izquierda) {
		this.izquierda = izquierda;
	}

	public NodoBinario getDerecha() {
		return derecha;
	}

	public void setDerecha(NodoBinario derecha) {
		this.derecha = derecha;
	}

}
