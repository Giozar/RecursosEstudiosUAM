package abb.clases;

public class ArbolBinarioBusqueda {
	
	private NodoBinario raiz;
	
	public ArbolBinarioBusqueda() {
		raiz = null;
	}

	public NodoBinario getRaiz() {
		return raiz;
	}

	public void setRaiz(NodoBinario raiz) {
		this.raiz = raiz;
	}
	
}
