public class Principal {

	public static void main(String[] args) {
		
		int A1 [ ];
		A1 = new int [ 30 ];
		
		int A2 [ ];
		A2 = new int [ 30 ];
		
		int A3 [ ];
		A3 = new int [ 60 ];
		
		int aux1, aux2;
		
		System.out.println("\n\t\t\t\t*~Primer Arreglo~*");
		for ( int i = 0 ; i < A1.length ; i++) {
			aux1 = ( int ) ( Math.random( )*15 + 1 );
			A1 [ i ] = aux1;
			System.out.print( " | " + A1 [ i ] + " " );
			
		}
		
		System.out.println("\n\n\t\t\t\t*~Segundo Arreglo~*");
		for ( int j = 0 ; j < A2.length ; j++ ) {
			aux2 = ( int ) ( Math.random( )*15 + 1);
			A2 [ j ] = aux2;
			System.out.print(" | " + A2 [ j ] + " ");
			
		}
		
		System.out.println("\n\n\n\t\t\t\t\t\t\t\t*******Ordenamiento por el m�todo de QUICKSORT*****");
		quicksort( A1 , 0 , A1.length - 1 );		
		System.out.println("\n\t\t~Primero arreglo ordenado~");
		
		for (int n=0 ; n < A1.length ; n++ ) 
			System.out.print( "| " + A1[ n ] + " ");        
		
		quicksort( A2 , 0 , A2.length - 1 );		
		System.out.println("\n\n\t\t~Segundo arreglo ordenado~");
		
		for (int n=0 ; n < A2.length ; n++ ) 			
            System.out.print( "| " + A2[ n ] + " ");
		
		System.out.println("\n\n\n\t\t\t\t\t\t\t\t******Ordenamiento por el m�todo de MERGESORT*****");
		
		A3 = odenaCombina( A1 , A2 );
        
		for (int n=0 ; n < A3.length ; n++ ) 
			System.out.print( "| " + A3[ n ] + " ");        
	}
	
	public static void quicksort ( int A [ ] , int izq , int der) {
		
		int pivote = A[ izq ];
		int i = izq;
		int j = der;
		int aux;
		
		while ( i < j ) {
			while ( A [ i ] <= pivote && i < j ) 
				i++;
			while ( A [ j ] > pivote )
				j--;
			if ( i < j ) {
				aux = A [ i ];
				A [ i ] = A [ j ];
				A [ j ] = aux;
			}
		}
		
		A [ izq ] = A [ j ];
		A [ j ] = pivote;
		if ( izq < j-1)
			quicksort ( A , izq , j-1);
		if ( j+1 < der )
			quicksort ( A , j+1 , der);
	}
	
	public static int [] odenaCombina(int [] a, int [] b){
        int [] result;
        result = new int[a.length + b.length];
       
        int posA = 0;
        int posB = 0;
        int posRes = 0;

        while(posA < a.length && posB < b.length){
            if(a[posA] < b[posB]){
                result[posRes] = a[posA];
                posRes++;
                posA++;
            }
            else{
                result[posRes] = b[posB];    
                posRes++;
                posB++;
            }
        }
       
        while(posA < a.length){
            result[posRes] = a[posA];
            posRes++;
            posA++;
        }
        while(posB < b.length){
            result[posRes] = b[posB];
            posRes++;
            posB++;
        }
        return result;
    }
}
