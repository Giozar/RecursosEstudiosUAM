package proyecto20;

public interface Monstruo {
    public abstract void formacomunicarse();
    
}
