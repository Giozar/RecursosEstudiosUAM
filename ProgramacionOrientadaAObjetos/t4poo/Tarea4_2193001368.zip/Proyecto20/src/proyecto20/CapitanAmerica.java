/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto20;

/**
 *
 * @author giova
 */
public class CapitanAmerica implements Personaje, Superheroe, Humano {
    
    @Override
    public void presentacion() {
        System.out.println("soy Steve Rogers");
    }


    @Override
    public String getNombre() {
        return "Capitan America";
    }

    @Override
    public int getCritico() {
        int poder = (int) Math.floor(Math.random()*5+1);
        return poder;
    }


    @Override
    public void debilidad() {
        System.out.println("daños a partes internas");
    }

    @Override
    public int vida() {
        int vida = 100;
        return vida;
    }

    @Override
    public int getPoder() {
        int getPoder = (int) Math.floor(Math.random()*7+1);
        return getPoder;
    }

    @Override
    public int defensa() {
        int defensa = (int) Math.floor(Math.random()*7+1);
        return defensa;
    }


    @Override
    public int getArmaHabilidad() {
        int habilidad = (int) Math.floor(Math.random()*(6-1))+1;
        return habilidad;
    }

    @Override
    public String nomArma(int habilidad) {
        String usa;
        switch (habilidad) {
            case 2: usa = "Da multiples golpes con sus puños";
            break;
            case 3: usa = "Laza su escudo";
            break;
            case 4: usa = "Lanza su escudo y causa multiples rebotes";
            break;
            case 5: usa = "Con su moto lo arrolla y explota";
            break;
            default: usa = "Da unas patadas";
            break;
        }
        return usa;
    }

    @Override
    public void mision() {
        System.out.println("salvar el mundo");
    }

    @Override
    public void ocupacion() {
        System.out.println("agente del gobierno");
    }
    
    
    
    
    
}
