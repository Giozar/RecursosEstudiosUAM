/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto20;

/**
 *
 * @author giova
 */
public interface Personaje {
    
    public abstract String getNombre();
    public abstract int getCritico();
    public abstract int getPoder();
    public abstract int defensa();
    public abstract int vida();
    public abstract String nomArma(int habilidad);
    //criterio de calificacion, arama habilidad con poder limitado, pero varia entre un rango
    public abstract int getArmaHabilidad();
    public abstract void presentacion();
    public abstract void debilidad();
}
