/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto20;

/**
 *
 * @author giova
 */
public class DoctorStrange implements Personaje, Humano, Superheroe {
    
    @Override
    public void presentacion() {
        System.out.println("soy el hechizero supremos");
    }


    @Override
    public String getNombre() {
        return "Dr strange";
    }

    @Override
    public int getCritico() {
        int poder = (int) Math.floor(Math.random()*10+1);
        return poder;
    }


    @Override
    public void debilidad() {
        System.out.println("la gemas del infinito");
    }

    @Override
    public int vida() {
        int vida = 100;
        return vida;
    }

    @Override
    public int getPoder() {
        int getPoder = (int) Math.floor(Math.random()*7+1);
        return getPoder;
    }

    @Override
    public int defensa() {
        int defensa = (int) Math.floor(Math.random()*9+1);
        return defensa;
    }


    @Override
    public int getArmaHabilidad() {
        int habilidad = (int) Math.floor(Math.random()*(10-2))+2;
        return habilidad;
    }

    @Override
    public String nomArma(int habilidad) {
        String usa;
        switch (habilidad) {
            
            case 7: usa = "crea un portal y ataca inesperadamente";
            break;
            case 8: usa = "para el tiempo y ataca muchas veces";
            break;
            case 9: usa = "Viaja en el multiverso y lo estrella con su otro yo y vuelve a la realidad normal";
            break;
            default: usa = "lanza rafagas de hechizos";
            break;
        }
        return usa;
    }

    @Override
    public void ocupacion() {
        System.out.println("maestro de las artes misticas");
    }

    @Override
    public void mision() {
        System.out.println("proteger la realidad");
    }
    
    
    
    
    
}
