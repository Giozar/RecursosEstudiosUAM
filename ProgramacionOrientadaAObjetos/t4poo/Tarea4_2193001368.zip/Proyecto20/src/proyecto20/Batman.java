/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto20;

/**
 *
 * @author giova
 */
public class Batman implements Personaje, Humano, Superheroe {
    
    @Override
    public void presentacion() {
        System.out.println("Soy batman");
    }


    @Override
    public String getNombre() {
        return "Bruce Wayne";
    }

    @Override
    public int getCritico() {
        int poder = (int) Math.floor(Math.random()*5+1);
        return poder;
    }


    @Override
    public void debilidad() {
        System.out.println("Daños a Extremidades");
    }

    @Override
    public int vida() {
        int vida = 100;
        return vida;
    }

    @Override
    public int getPoder() {
        int getPoder = (int) Math.floor(Math.random()*7+1);
        return getPoder;
    }

    @Override
    public int defensa() {
        int defensa = (int) Math.floor(Math.random()*9+1);
        return defensa;
    }


    @Override
    public int getArmaHabilidad() {
        int habilidad = (int) Math.floor(Math.random()*(8-2))+2;
        return habilidad;
    }

    @Override
    public String nomArma(int habilidad) {
        String usa;
        switch (habilidad) {
            case 4: usa = "Da puños y patadas multiples";
            break;
            case 5: usa = "lanza batarangs";
            break;
            case 6: usa = "Lo atrae con su gancho y le da un super golpe";
            break;
            case 7: usa = "Llama a su Batnave y dispara rafagas de explosivos";
            break;
            default: usa = "Lanza gas y te golpea";
            break;
        }
        return usa;
    }

    @Override
    public void ocupacion() {
        System.out.println("empresario multimillonario");
    }

    @Override
    public void mision() {
        System.out.println("proteger la tierra y ciudad gotica");
    }
    
    
    
    
    
}
