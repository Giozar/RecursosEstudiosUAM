package proyecto20;

public interface Humano {
    public abstract void ocupacion();
    
}
