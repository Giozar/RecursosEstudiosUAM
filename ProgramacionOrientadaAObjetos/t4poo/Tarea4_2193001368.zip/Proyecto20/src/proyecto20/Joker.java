/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto20;

/**
 *
 * @author giova
 */
public class Joker implements Personaje, Villano, Humano {

    @Override
    public String getNombre() {
        return "Joker";
    }

    @Override
    public int getCritico() {
        int poder = (int) Math.floor(Math.random()*3+1);
        return poder;
    }

    @Override
    public int getPoder() {
        int getPoder = (int) Math.floor(Math.random()*6+1);
        return getPoder;
    }

    @Override
    public int defensa() {
        int defensa = (int) Math.floor(Math.random()*6+1);
        return defensa;
    }

    @Override
    public int vida() {
        return 100;
    }

    @Override
    public int getArmaHabilidad() {
        return 3;
    }

    @Override
    public void presentacion() {
        System.out.println("HAHAHAHA");
    }

    @Override
    public void debilidad() {
        System.out.println("Daño a extremidades");
    }

    @Override
    public void proposito() {
        System.out.println("Causar caos");
    }

    @Override
    public void ocupacion() {
        System.out.println("hacerle la vida imposible a batman");
    }

    @Override
    public String nomArma(int habilidad) {
        return "Palanca";
    }
    
}
