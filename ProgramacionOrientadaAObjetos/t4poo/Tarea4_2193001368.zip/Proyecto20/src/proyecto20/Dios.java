package proyecto20;
public interface Dios extends Personaje {
    public abstract void habilidad();
}
