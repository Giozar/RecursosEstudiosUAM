
package proyecto20;

public interface Alien {
    public abstract void planeta();
}
