/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto20;

/**
 *
 * @author giova
 */
public class Darksaide implements Personaje, Villano, Alien {
    
    @Override
    public void presentacion() {
        System.out.println("Vengo a conquistar el mundo");
    }


    @Override
    public String getNombre() {
        return "Darkside";
    }

    @Override
    public int getCritico() {
        int poder = (int) Math.floor(Math.random()*6+1);
        return poder;
    }


    @Override
    public void debilidad() {
        System.out.println("sus ojos");
    }

    @Override
    public int vida() {
        int vida = 100;
        return vida;
    }

    @Override
    public int getPoder() {
        int getPoder = (int) Math.floor(Math.random()*16+1);
        return getPoder;
    }

    @Override
    public int defensa() {
        int defensa = (int) Math.floor(Math.random()*12+1);
        return defensa;
    }


    @Override
    public int getArmaHabilidad() {
        int habilidad = (int) Math.floor(Math.random()*(18-10))+10;
        return habilidad;
    }

    @Override
    public String nomArma(int habilidad) {
        String usa;
        switch (habilidad) {
            case 17: usa = "Te teletransporta y lo totura";
            break;
            case 18: usa = " Laser de sus ojos";
            break;
            default: usa = "Super golpe";
            break;
        }
        return usa;
    }

    @Override
    public void proposito() {
        System.out.println("conquitar el mundo");
    }

    @Override
    public void planeta() {
        System.out.println("apocalipsis");
    }
    
    
    
    
    
}
