/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto20;

/**
 *
 * @author giova
 */
public class Spiderman implements Personaje, Humano, Superheroe {

    @Override
    public String getNombre() {
        return "Spiderman";
    }

    @Override
    public int getCritico() {
        int poder = (int) Math.floor(Math.random()*6+1);
        return poder;
    }


    @Override
    public void presentacion() {
        System.out.println("soy el increible hombre que araña");
    }

    @Override
    public void debilidad() {
        System.out.println("mi familia");
    }

    @Override
    public void ocupacion() {
        System.out.println("estudiante");
    }

    @Override
    public void mision() {
        System.out.println("salvar el mundo");
    }

    @Override
    public int vida() {
        int vida = 100;
        return vida;
    }

    @Override
    public int getPoder() {
        int getPoder = (int) Math.floor(Math.random()*6+1);
        return getPoder;
    }

    @Override
    public int defensa() {
        int defensa = (int) Math.floor(Math.random()*6+1);
        return defensa;
    }

    @Override
    public int getArmaHabilidad() {
        int habilidad = (int) Math.floor(Math.random()*6+1);
        return habilidad;
    }

    @Override
    public String nomArma(int habilidad) {
        String usa;
        switch (habilidad) {
            case 1: usa = "Ataca con telaraña";
            break;
            case 2: usa = "Super golpe";
            break;
            case 3: usa = "Da patadas voladoras";
            break;
            case 4: usa = "Lanza bombitas de telaaraña";
            break;
            case 5: usa = "Activa el IronSpider y ataca con su modo asesino";
            break;
            default: usa = "Te azota repetiamete";
            break;
        }
        
        return usa;
    }
    
}
