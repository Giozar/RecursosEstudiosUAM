package proyecto20;

public interface Villano {
    public abstract void proposito();
    
}
