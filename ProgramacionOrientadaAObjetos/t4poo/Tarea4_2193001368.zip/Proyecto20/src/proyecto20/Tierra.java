package proyecto20;

/**
 * @author giova
 */
public class Tierra {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //se crea la coleecion de heroes y villanos
        Personaje [] villanos = new Personaje[15];
        Personaje [] superheroes = new Personaje[15];
        
        int teamHeroes = 0;
        int teamVillanos = 0;
        
        //se instancian los heroes y villanos
        villanos[0] = new Thanos();
        villanos[1] = new Skrull();
        villanos[2] = new Joker();
        villanos[3] = new MuerteRoja();
        villanos[4] = new Doomsday();
        villanos[5] = new Darksaide();
        villanos[6] = new Deathstroke();
        villanos[7] = new Riven();
        villanos[8] = new Venom();
        villanos[9] = new DoctorOctopus();
        villanos[10] = new Carnage();
        villanos[11] = new Lobo();
        villanos[12] = new BlackAdam();
        villanos[13] = new BlackManta();
        villanos[14] = new Magneto();
        
        
        superheroes[0] = new Thor();
        superheroes[1] = new Spiderman();
        superheroes[2] = new MujerMaravilla();
        superheroes[3] = new IronMan();
        superheroes[4] = new Hulk();
        superheroes[5] = new CapitanAmerica();
        superheroes[6] = new Batman();
        superheroes[7] = new Flash();
        superheroes[8] = new SuperMan();
        superheroes[9] = new DrManhattan();
        superheroes[10] = new SuperGirl();
        superheroes[11] = new DoctorStrange();
        superheroes[12] = new Wolverine();
        superheroes[13] = new Deadpool();
        superheroes[14] = new Rorschach();
        
        System.out.println("Seleccion de villanos:");
        Personaje[] elegidosVi = seleccionar(villanos,10);
        System.out.println("");
        System.out.println("Seleccion de heroes:");
        Personaje[] elegidosSu = seleccionar(superheroes,10);

        for (int i = 0; i < elegidosVi.length; i++) {
           int res = batalla(elegidosSu[i],elegidosVi[i]);
           if(res == 1){teamHeroes++;}
           else if(res == 0){teamVillanos++;}
        }
        
        if(teamHeroes>teamVillanos){
            System.out.println("¡¡¡GANA EQUIPO DE HEROESS!!!");
        }else if(teamVillanos>teamHeroes){
            System.out.println("¡¡¡GANA EQUIPO DE VILLANOS!!!");
        }else{
            System.out.println("EMPATEE !!");
        }
        
    }
    
    //creo mi funcion que realiza la batalla
    static int batalla(Personaje su,Personaje vi){    
        
        System.out.println("Batalla entre ");
        //su.presentacion();
        System.out.println(su.getNombre());
        //--------((Superheroe) su).mision();
        System.out.println("contra... ");
        //vi.presentacion();
        System.out.println(vi.getNombre());
       //--------((Villano) vi).proposito();
       
       //se adquiere el valor de la vida
       int vidaSu = su.vida();
       int vidaVi = vi.vida();
       //criterio de degradacion de poder, en cada ciclo sus poderes disminuyen
       int degradacionPoder = 0;
       //inicio de combate
        while( (vidaSu > 0) && (vidaVi > 0)){
            
            //getPoder de villano
            //probabilidades de que getPoder el villano
            int num1 = (int) Math.floor(Math.random()*10+1);
            int num2 = (int) Math.floor(Math.random()*10+1);
            int num3 = (int) Math.floor(Math.random()*10+1);
            int critico1 = (int) Math.floor(Math.random()*10+1);
            int defensa1 = (int) Math.floor(Math.random()*10+1);
            int arma1 = (int) Math.floor(Math.random()*10+1);
            
            //desiciones de getPoder de villano
            if( num1 < 5 ){
                
                System.out.println(vi.getNombre() + " inicia a atacar");
                
                if( num2 > 5 ){//probabilidad de fallar el villano
                    
                    System.out.println(su.getNombre() + " esquivo golpe");
                    
                    if( num3 > 5 ){//probabilidad de contratacar heroe
                        
                        System.out.println("contrataca rapido");
                        
                        vidaVi-=5;//villano pierde vida
                        
                        System.out.println(vi.getNombre() + " sufre daño");
                        
                        System.out.println("Vida heroe: " + vidaSu);
                        
                        System.out.println("Vida villano: " + vidaVi);
                    }
                }
                else{//si villano no falla
                    
                    //probabilidad de usar habiidad o arma
                    if(arma1 >= 5){
                        //si villano tiene arma
                        if(vi.getArmaHabilidad()>0){
                            
                            int habilidad = vi.getArmaHabilidad();
                                    
                            vidaSu-=habilidad;
                            
                            System.out.println("tipo de habilidad o arma: " + habilidad);
                            
                            System.out.println("ataca con " + vi.nomArma(habilidad));
                            
                            System.out.println(su.getNombre() + " sufre daño");
                        }
                    }else{System.out.println("No usa habilidad y ni arma");}
                    
                    //----------------------------------------------------------
                    
                    int poder1 = vi.getPoder();
                    
                    poder1-=degradacionPoder;
                    
                    if(poder1 > 0){
                        System.out.println(vi.getNombre() + " ataca con fuerza");
                    
                        vidaSu -= (10 + poder1);//heroe pierde vida
                    
                        System.out.println(su.getNombre() + " sufre daño");
                    }
                    //----------------------------------------------------------
                    
                    //probabilidad de hacer un getPoder critico
                    if( critico1 > 3 ){
                        
                        int poderCritico1 = vi.getCritico();
                        //heroe recibe daño critico
                        vidaSu-= poderCritico1;
                        
                        System.out.println("Golpe critico de " + poderCritico1);
                        
                        System.out.println(su.getNombre() + " sufre daño");
                    }
                    
                    //probabilidad de recuperacion heroe
                    if( defensa1 > 5 ){
                        
                        int recu1 = su.defensa();
                        //heroe se recupera
                        vidaSu += recu1 ;
                        
                        System.out.println("pero recupera " + recu1 + " de salud");
                        
                    }
                    
                    //fin de batalla, muestra vidas finales
                    System.out.println("Vida heroe: " + vidaSu);
                        
                    System.out.println("Vida villano: " + vidaVi);
                }
            }
            else{//getPoder de heroe
                int num4 = (int) Math.floor(Math.random()*10+1);
                int num5 = (int) Math.floor(Math.random()*10+1);
                int num6 = (int) Math.floor(Math.random()*10+1);
                int critico2 = (int) Math.floor(Math.random()*10+1);
                int defensa2 = (int) Math.floor(Math.random()*10+1);
                int arma2 = (int) Math.floor(Math.random()*10+1);
                
                //desiciones getPoder heroe
                if( num4 > 5 ){
                    
                    System.out.println(su.getNombre() + " inicia a atacar");
                    
                    if( num5 > 5 ){//probabilidad de fallar heroe
                        
                        System.out.println(vi.getNombre() + " esquivo golpe");
                        
                        if( num6 > 5 ){//probabilidad de contratacar villano
                            
                            System.out.println("contrataca rapido");
                            
                            vidaSu-=5;//heroe pierde vida
                            
                            System.out.println(su.getNombre() + " sufre daño");
                            
                            System.out.println("Vida heroe: " + vidaSu);
                            
                            System.out.println("Vida villano: " + vidaVi);
                        }
                    }//si heroe no falla
                    else{
                        
                        //probabilidad de usar habiidad o arma
                        if(arma2 >= 5){
                            //si heroe tiene arma
                            if(su.getArmaHabilidad()>0){
                            
                                int habilidad = su.getArmaHabilidad();
                                  
                                vidaVi-=habilidad;
                                System.out.println("tipo de habilidad o arma: " + habilidad);
                                
                                System.out.println("ataca con " + su.nomArma(habilidad));
                            
                                System.out.println(vi.getNombre() + " sufre daño");
                            }
                        }else{System.out.println("no usa arma ni habilidad");}
                        
                        //------------------------------------------------------
                        
                        int poder2 = su.getPoder();
                    
                        poder2-=degradacionPoder;
                    
                        if(poder2 > 0){
                            System.out.println(vi.getNombre() + " ataca con fuerza");
                    
                            vidaVi -= (10 + poder2);//villano pierde vida
                    
                            System.out.println(vi.getNombre() + " sufre daño");
                        }
                        //--------------------------------------------------
                        
                        
                        //probabilidad de hacer daño critico
                        if( critico2 > 3 ){
                            
                            int poderCritico2 = su.getCritico();
                            //heroe recibe daño critico
                            vidaVi -= poderCritico2;
                            
                            System.out.println("Golpe critico de " + poderCritico2);
                            
                            System.out.println(vi.getNombre() + " sufre daño");
                        }
                        
                        //probabilidad de que se recuere el villano
                        if( defensa2 > 5 ){
                            
                            int recu2 = vi.defensa();
                            
                            //villano se recupera
                            vidaVi += recu2;
                            
                            System.out.println("pero recupera " + recu2 + " de salud");
                        }
                        
                        //muestra vidas finales
                    
                        System.out.println("Vida heroe: " + vidaSu);
                        
                        System.out.println("Vida villano: " + vidaVi);
                    }
                }
            }
        }
        //aumento de la degradacion
        degradacionPoder++;
        //descicion de victoria
        if( vidaSu > vidaVi ){
            
            System.out.println("--------Gana "+su.getNombre() +"-------");
            return 1;
            
        }else{
            System.out.println("--------Gana "+vi.getNombre() +"--------");
            return 0;
        }
        //fin de combate
        
    }
    
    //eleccion aleatoria de personajes
    static Personaje[] seleccionar(Personaje[] sujetos, int participantes){
        
        Personaje[] seleccionados = new Personaje[participantes];
        
        int i = 0;
        
        while(i < participantes){
            int num = (int) Math.floor(Math.random()*sujetos.length);
            //System.out.print(num);
            seleccionados[i] = sujetos[num];
            System.out.print("se seleciono a " + seleccionados[i].getNombre()+"||");
            i++;
        }
        return seleccionados;
    }
    
}
