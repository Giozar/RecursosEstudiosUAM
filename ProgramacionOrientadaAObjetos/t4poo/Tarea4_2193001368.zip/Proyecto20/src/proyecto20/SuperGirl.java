/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto20;

/**
 *
 * @author giova
 */
public class SuperGirl implements Personaje,Humano,Alien,Dios,Superheroe {
    
    @Override
    public void presentacion() {
        System.out.println("Hola soy clark kent");
    }


    @Override
    public String getNombre() {
        return "Superman";
    }

    @Override
    public int getCritico() {
        int poder = (int) Math.floor(Math.random()*10+1);
        return poder;
    }


    @Override
    public void debilidad() {
        System.out.println("kriptonita");
    }

    @Override
    public int vida() {
        int vida = 100;
        return vida;
    }

    @Override
    public int getPoder() {
        int getPoder = (int) Math.floor(Math.random()*8+1);
        return getPoder;
    }

    @Override
    public int defensa() {
        int defensa = (int) Math.floor(Math.random()*8+1);
        return defensa;
    }


    @Override
    public int getArmaHabilidad() {
        int habilidad = (int) Math.floor(Math.random()*(10-2))+2;
        return habilidad;
    }

    @Override
    public String nomArma(int habilidad) {
        String usa;
        switch (habilidad) {
            case 5: usa = "Super puño";
            break;
            case 6: usa = "Vision laser";
            break;
            case 7: usa = "te levanta y golpea contra el suelo";
            break;
            case 8: usa = "te agarra y te lleva a la etratosfera y te deja caer con impulso";
            break;
            case 9: usa = "da la vuelta al mundo y da un super golpe";
            break;
            default: usa = "te sopla";
            break;
        }
        return usa;
    }

    @Override
    public void ocupacion() {
        System.out.println("periodista");
    }

    @Override
    public void planeta() {
        System.out.println("kripton");
    }

    @Override
    public void habilidad() {
        System.out.println("volar, vision laser, super fuerza");
    }

    @Override
    public void mision() {
        System.out.println("proteger el mundo y el universo");
    }
    
    
    
    
    
}
