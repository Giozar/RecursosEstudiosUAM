/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto20;

/**
 *
 * @author giova
 */
public class IronMan implements Personaje, Humano{

    @Override
    public String getNombre() {
        return "Ion Man";
    }

    @Override
    public int getCritico() {
        int poder = (int) Math.floor(Math.random()*4+1);
        return poder;
    }

    @Override
    public int getPoder() {
        int getPoder = (int) Math.floor(Math.random()*7+1);
        return getPoder;
    }

    @Override
    public int defensa() {
        int defensa = (int) Math.floor(Math.random()*6+1);
        return defensa;
    }

    @Override
    public int vida() {
        return 100;
    }

    @Override
    public int getArmaHabilidad() {
        return 8;
    }

    @Override
    public void presentacion() {
        System.out.println("I am Iron Man");
    }

    @Override
    public void debilidad() {
        System.out.println("su familia");
    }

    @Override
    public void ocupacion() {
        System.out.println("Filantropo, Playbol, multimillonario, dueño de industria Strak");
    }

    @Override
    public String nomArma(int habilidad) {
        return "Blaster de plasma";
    }
    
}
