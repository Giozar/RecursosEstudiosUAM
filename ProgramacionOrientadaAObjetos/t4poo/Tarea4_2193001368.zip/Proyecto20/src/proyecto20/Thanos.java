/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto20;

/**
 *
 * @author giova
 */
public class Thanos implements Personaje, Villano,Alien {

    @Override
    public void presentacion() {
        System.out.println("soy inevitable");
    }

    @Override
    public void debilidad() {
        System.out.println("la muerte");
    }

    @Override
    public void proposito() {
        System.out.println("destruir mundo");
    }

    @Override
    public void planeta() {
        System.out.println("Titan");
    }

    @Override
    public String getNombre() {
        return "Thanos";
    }

    @Override
    public int getCritico() {
        int poder = (int) Math.floor(Math.random()*8+1);
        return poder;
    }


    @Override
    public int vida() {
        int vida = 100;
        return vida;
    }

    @Override
    public int getPoder() {
        int getPoder = (int) Math.floor(Math.random()*12+1);
        return getPoder;
    }

    @Override
    public int defensa() {
        int defensa = (int) Math.floor(Math.random()*9+1);
        return defensa;
    }


    @Override
    public int getArmaHabilidad() {
        int habilidad = (int) Math.floor(Math.random()*(20-10))+10;
        return habilidad;
    }

    @Override
    public String nomArma(int habilidad) {
        String usa;
        switch (habilidad) {
            case 16: usa = "laser del guantelete";
            break;
            case 17: usa = "Varios golpes hasta deformarle el rostro";
            break;
            case 18: usa = "Parar el tiempo y lo aplasta";
            break;
            case 19: usa = "Golpe con la gema del poder";
            break;
            case 20: usa = "Usa el guantelete con toda las gemas y lo hace polvo";
            break;
            default: usa = "Su espada y ataca varias veces";
            break;
        }
        return usa;
    }
    
}
