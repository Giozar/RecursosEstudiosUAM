package proyecto20;
public interface Superheroe {
    public abstract void mision();
}
