/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto20;

/**
 *
 * @author giova
 */
public class MujerMaravilla implements Dios, Superheroe {

    @Override
    public void habilidad() {
        System.out.println("super fuerza");
    }

    @Override
    public void mision() {
        System.out.println("salvar el mundo");
    }

    @Override
    public String getNombre() {
        return "la mujer maravilla";
    }

    @Override
    public int getCritico() {
        int poder = (int) Math.floor(Math.random()*6+1);
        return poder;
    }


    @Override
    public void presentacion() {
        System.out.println("soy la mujer maravilla");
    }

    @Override
    public void debilidad() {
        System.out.println("cuando pide deseos");
    }

    @Override
    public int vida() {
        int vida = 100;
        return vida;
    }

    @Override
    public int getPoder() {
        int getPoder = (int) Math.floor(Math.random()*6+1);
        return getPoder;
    }

    @Override
    public int defensa() {
        int defensa = (int) Math.floor(Math.random()*6+1);
        return defensa;
    }

    @Override
    public int getArmaHabilidad() {
        int espada = 7;
        return espada;
    }

    @Override
    public String nomArma(int habilidad) {
        return "Espada y Escudo";
    }
    
}
