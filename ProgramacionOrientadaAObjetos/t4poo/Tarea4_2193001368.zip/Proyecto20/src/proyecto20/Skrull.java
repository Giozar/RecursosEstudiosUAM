/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto20;

/**
 *
 * @author giova
 */
public class Skrull implements Personaje, Villano, Monstruo, Alien {

    @Override
    public void presentacion() {
        System.out.println("soy un skrul gr");
    }
    
    @Override
    public void debilidad() {
        System.out.println("daño a extremidades");
    }

    @Override
    public void proposito() {
        System.out.println("invadir");
    }

    @Override
    public void formacomunicarse() {
        System.out.println("gruñidos");
    }

    @Override
    public void planeta() {
            System.out.println("planeta xd");
    }

    @Override
    public String getNombre() {
        return "un scrull";
    }

    @Override
    public int getCritico() {
        int poder = (int) Math.floor(Math.random()*6+1);
        return poder;
    }


    @Override
    public int vida() {
        int vida = 100;
        return vida;
    }

    @Override
    public int getPoder() {
        int getPoder = (int) Math.floor(Math.random()*6+1);
        return getPoder;
    }

    @Override
    public int defensa() {
        int defensa = (int) Math.floor(Math.random()*6+1);
        return defensa;
    }

    @Override
    public int getArmaHabilidad() {
        return 0;
    }

    @Override
    public String nomArma(int habilidad) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
