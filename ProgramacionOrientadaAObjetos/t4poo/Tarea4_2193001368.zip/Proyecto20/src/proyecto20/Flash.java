/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto20;

/**
 *
 * @author giova
 */
public class Flash implements Personaje, Humano, Superheroe {
    
    @Override
    public void presentacion() {
        System.out.println("Soy Barry Allen");
    }


    @Override
    public String getNombre() {
        return "The flash";
    }

    @Override
    public int getCritico() {
        int poder = (int) Math.floor(Math.random()*6+1);
        return poder;
    }


    @Override
    public void debilidad() {
        System.out.println("Speed Force");
    }

    @Override
    public int vida() {
        int vida = 100;
        return vida;
    }

    @Override
    public int getPoder() {
        int getPoder = (int) Math.floor(Math.random()*9+1);
        return getPoder;
    }

    @Override
    public int defensa() {
        int defensa = (int) Math.floor(Math.random()*9+1);
        return defensa;
    }


    @Override
    public int getArmaHabilidad() {
        int habilidad = (int) Math.floor(Math.random()*(10-2))+2;
        return habilidad;
    }

    @Override
    public String nomArma(int habilidad) {
        String usa;
        switch (habilidad) {
            case 5: usa = "Dispara superrayo";
            break;
            case 6: usa = "Corre y da Super golpe";
            break;
            case 7: usa = "Corre haciendo un tornado";
            break;
            case 8: usa = "Da muchos golpes rapidos";
            break;
            case 9: usa = "Viaja en el tiempo y hace chocarlo consigo mismo";
            break;
            default: usa = "Lo empuja y antes de caer da 10 patadas";
            break;
        }
        
        return usa;
    }

    @Override
    public void ocupacion() {
        System.out.println("criminalista forence");
    }

    @Override
    public void mision() {
        System.out.println("proteger central city");
    }
    
    
    
    
    
}
