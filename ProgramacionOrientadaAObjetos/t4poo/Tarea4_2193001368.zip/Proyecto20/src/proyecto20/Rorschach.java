/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto20;

/**
 *
 * @author giova
 */
public class Rorschach implements Personaje, Humano {
    
    @Override
    public void presentacion() {
        System.out.println("Los hhombres van a la carcel y los perros asesinados");
    }


    @Override
    public String getNombre() {
        return "Rorschach";
    }

    @Override
    public int getCritico() {
        int poder = (int) Math.floor(Math.random()*6+1);
        return poder;
    }


    @Override
    public void debilidad() {
        System.out.println("");
    }

    @Override
    public int vida() {
        int vida = 100;
        return vida;
    }

    @Override
    public int getPoder() {
        int getPoder = (int) Math.floor(Math.random()*6+1);
        return getPoder;
    }

    @Override
    public int defensa() {
        int defensa = (int) Math.floor(Math.random()*6+1);
        return defensa;
    }


    @Override
    public int getArmaHabilidad() {
        int habilidad = (int) Math.floor(Math.random()*(10-2))+2;
        return habilidad;
    }

    @Override
    public String nomArma(int habilidad) {
        String usa;
        switch (habilidad) {
            case 5: usa = "Pistola y dispara";
            break;
            case 6: usa = "Arma blanca";
            break;
            default: usa = "Varios golpes en partes y extremidades";
            break;
        }
        return usa;
    }

    @Override
    public void ocupacion() {
        System.out.println("proteger a las personas buenas");
    }
    
    
    
    
    
}
