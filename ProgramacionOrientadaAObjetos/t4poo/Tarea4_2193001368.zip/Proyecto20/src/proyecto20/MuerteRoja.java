/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto20;

/**
 *
 * @author giova
 */
public class MuerteRoja implements Personaje , Humano , Villano {

    @Override
    public String getNombre() {
        return "Red Death";
    }

    @Override
    public int getCritico() {
        int poder = (int) Math.floor(Math.random()*6+1);
        return poder;
    }

    @Override
    public int getPoder() {
        int getPoder = (int) Math.floor(Math.random()*6+1);
        return getPoder;
    }

    @Override
    public int defensa() {
        int defensa = (int) Math.floor(Math.random()*6+1);
        return defensa;
    }

    @Override
    public int vida() {
        return 100;
    }

    public String nomArma(int habilidad) {
        String usa;
        switch (habilidad) {
            case 5: usa = "Dispara superrayo";
            break;
            case 6: usa = "Corre y da Super golpe";
            break;
            case 7: usa = "Corre haciendo un tornado";
            break;
            case 8: usa = "Da muchos golpes rapidos";
            break;
            case 9: usa = "Viaja en el tiempo y hace chocarlo consigo mismo";
            break;
            default: usa = "Lo empuja y antes de caer da 10 patadas";
            break;
        }
        
        return usa;
    }

    @Override
    public int getArmaHabilidad() {
        int habilidad = (int) Math.floor(Math.random()*(10-2))+2;
        return habilidad;
        
    }

    @Override
    public void presentacion() {
        System.out.println("soy la muerte roja");
    }

    @Override
    public void debilidad() {
        System.out.println("speed force");
    }

    @Override
    public void ocupacion() {
        System.out.println("acabar con los batmans del multiverso");
    }

    @Override
    public void proposito() {
        System.out.println("ser el mas rapido del multiverso");
    }
    
}
