/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto20;

/**
 *
 * @author giova
 */
public class Magneto implements Personaje, Villano, Humano {
    
    @Override
    public void presentacion() {
        System.out.println("es hora de metalizarte");
    }


    @Override
    public String getNombre() {
        return "Magnetos";
    }

    @Override
    public int getCritico() {
        int poder = (int) Math.floor(Math.random()*8+1);
        return poder;
    }


    @Override
    public void debilidad() {
        System.out.println("si le quitan su casco");
    }

    @Override
    public int vida() {
        int vida = 100;
        return vida;
    }

    @Override
    public int getPoder() {
        int getPoder = (int) Math.floor(Math.random()*12+1);
        return getPoder;
    }

    @Override
    public int defensa() {
        int defensa = (int) Math.floor(Math.random()*8+1);
        return defensa;
    }


    @Override
    public int getArmaHabilidad() {
        int habilidad = (int) Math.floor(Math.random()*(12-7))+7;
        return habilidad;
    }

    @Override
    public String nomArma(int habilidad) {
        String usa;
        switch (habilidad) {
            case 10: usa = "metales y los lanza sin para";
            break;
            case 11: usa = "incrsuta metales en el cuerpo";
            break;
            case 12: usa = "crea campo de metal y lo comprime";
            break;
            default: usa = "pedazos de metales";
            break;
        }
        return usa;
    }

    @Override
    public void proposito() {
        System.out.println("acabar con los que se interponen en su camino");
    }

    @Override
    public void ocupacion() {
        System.out.println("hacer lo que considere correcto");
    }
    
    
    
    
    
}
