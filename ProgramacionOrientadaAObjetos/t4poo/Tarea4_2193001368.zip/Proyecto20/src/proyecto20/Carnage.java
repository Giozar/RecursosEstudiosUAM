/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto20;

/**
 *
 * @author giova
 */
public class Carnage implements Personaje, Villano, Alien, Humano {
    
    @Override
    public void presentacion() {
        System.out.println("Es hora de la carniceria");
    }


    @Override
    public String getNombre() {
        return "Carnage";
    }

    @Override
    public int getCritico() {
        int poder = (int) Math.floor(Math.random()*6+1);
        return poder;
    }


    @Override
    public void debilidad() {
        System.out.println("frecuencias bajas");
    }

    @Override
    public int vida() {
        int vida = 100;
        return vida;
    }

    @Override
    public int getPoder() {
        int getPoder = (int) Math.floor(Math.random()*9+1);
        return getPoder;
    }

    @Override
    public int defensa() {
        int defensa = (int) Math.floor(Math.random()*11+1);
        return defensa;
    }


    @Override
    public int getArmaHabilidad() {
        int habilidad = (int) Math.floor(Math.random()*(15-5))+5;
        return habilidad;
    }

    @Override
    public String nomArma(int habilidad) {
        String usa;
        switch (habilidad) {
            case 10: usa = "tentaculos y lo extrangula";
            break;
            case 12: usa = "puaz de sus manos";
            break;
            case 13: usa = "super mazos de sus manos";
            break;
            case 14: usa = "hachas de susmanos";
            break;
            case 15: usa = "mordidas feroces";
            break;
            default: usa = "golpes varias veces";
            break;
        }
        return usa;
    }
    
    @Override
    public void proposito() {
        System.out.println("causar el caos");
    }

    @Override
    public void planeta() {
        System.out.println("Klyntar");
    }

    @Override
    public void ocupacion() {
        System.out.println("destruir a cualquiera en su camino");
    }
    
    
    
    
    
}
