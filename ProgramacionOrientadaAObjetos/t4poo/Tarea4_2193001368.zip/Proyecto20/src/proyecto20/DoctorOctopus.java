/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto20;

/**
 *
 * @author giova
 */
public class DoctorOctopus implements Personaje, Villano, Humano {
    
    @Override
    public void presentacion() {
        System.out.println("");
    }


    @Override
    public String getNombre() {
        return "Doctor Octopus";
    }

    @Override
    public int getCritico() {
        int poder = (int) Math.floor(Math.random()*7+1);
        return poder;
    }


    @Override
    public void debilidad() {
        System.out.println("brazos mecanicos");
    }

    @Override
    public int vida() {
        int vida = 100;
        return vida;
    }

    @Override
    public int getPoder() {
        int getPoder = (int) Math.floor(Math.random()*12+1);
        return getPoder;
    }

    @Override
    public int defensa() {
        int defensa = (int) Math.floor(Math.random()*7+1);
        return defensa;
    }


    @Override
    public int getArmaHabilidad() {
        int habilidad = (int) Math.floor(Math.random()*(10-2))+2;
        return habilidad;
    }

    @Override
    public String nomArma(int habilidad) {
        String usa;
        switch (habilidad) {
            case 7: usa = "lanzza bombas";
            break;
            case 8: usa = "tentaculos y extrangula";
            break;
            case 9: usa = "navajas de tentaculos";
            break;
            default: usa = "tentaculos y golpea muchas veces ";
            break;
        }
        return usa;
    }

    @Override
    public void proposito() {
        System.out.println("destruir a spiderman");
    }

    @Override
    public void ocupacion() {
        System.out.println("crear mejoras roboticas para el mal");
    }
    
    
    
    
    
}
