/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto20;

/**
 *
 * @author giova
 */
public class BlackAdam implements Personaje, Villano, Dios {
    
    @Override
    public void presentacion() {
        System.out.println("shazam");
    }


    @Override
    public String getNombre() {
        return "Black Adam";
    }

    @Override
    public int getCritico() {
        int poder = (int) Math.floor(Math.random()*6+1);
        return poder;
    }


    @Override
    public void debilidad() {
        System.out.println("la muerte");
    }

    @Override
    public int vida() {
        int vida = 100;
        return vida;
    }


    @Override
    public int getPoder() {
        int getPoder = (int) Math.floor(Math.random()*8+1);
        return getPoder;
    }

    @Override
    public int defensa() {
        int defensa = (int) Math.floor(Math.random()*8+1);
        return defensa;
    }


    @Override
    public int getArmaHabilidad() {
        int habilidad = (int) Math.floor(Math.random()*(18-8))+8;
        return habilidad;
    }

    @Override
    public String nomArma(int habilidad) {
        String usa;
        switch (habilidad) {
            case 14: usa = "Super puño";
            break;
            case 15: usa = "relampagos";
            break;
            case 16: usa = "te levanta y golpea contra el suelo";
            break;
            case 17: usa = "te agarra y te lleva a la etratosfera y te deja caer con impulso";
            break;
            case 18: usa = "da la vuelta al mundo y da un super golpe";
            break;
            default: usa = "golpes de rayos";
            break;
        }
        return usa;
    }

    @Override
    public void proposito() {
        System.out.println("acabar con el capitan marvel");
    }

    @Override
    public void habilidad() {
        System.out.println("rayos, super fuerza, velocidad, volar");
    }
    
    
    
    
    
}
