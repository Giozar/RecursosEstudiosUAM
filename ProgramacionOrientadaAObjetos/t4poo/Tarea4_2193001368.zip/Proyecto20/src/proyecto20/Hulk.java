/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto20;

/**
 *
 * @author giova
 */
public class Hulk implements Personaje, Humano, Monstruo {

    @Override
    public String getNombre() {
        return "Brus Baner";
    }

    @Override
    public int getCritico() {
        int poder = (int) Math.floor(Math.random()*6+1);
        return poder;
    }

    @Override
    public int getPoder() {
        int getPoder = (int) Math.floor(Math.random()*6+1);
        return getPoder;
    }

    @Override
    public int defensa() {
        int defensa = (int) Math.floor(Math.random()*6+1);
        return defensa;
    }

    @Override
    public int vida() {
        return 100;
    }


    @Override
    public int getArmaHabilidad() {
        return 0;
    }

    @Override
    public void presentacion() {
        System.out.println("HULK APLASTAAA!!");
    }

    @Override
    public void debilidad() {
        System.out.println("su amada");
    }

    @Override
    public void ocupacion() {
        System.out.println("cientifico");
    }

    @Override
    public void formacomunicarse() {
        System.out.println("hablando");
    }

    @Override
    public String nomArma(int habilidad) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
