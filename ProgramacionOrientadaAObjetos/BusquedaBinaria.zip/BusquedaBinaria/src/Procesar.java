import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.StringTokenizer;

public class Procesar {

public Alumno [] llenarArreglAlumno(String archivo) {
		
		
		int i=0;
		int nAlumnos;
		String cadenaLeida ="";
		Alumno [] arregloAlumnos = null;
		
		//Para manejar un archivo de lectura
		FileReader fr;
		
			try{
				
				//Se abre el archivo a partir del nombre recibido
				fr =new FileReader(archivo);
				BufferedReader archivoLectura =new BufferedReader(fr);
				
				/*Se lee el total de alumnos y se convierte a entero
				 * para generar el arreglo
				 */
				cadenaLeida =archivoLectura.readLine();
				nAlumnos = Integer.parseInt(cadenaLeida);
				arregloAlumnos = new Alumno[nAlumnos];
				
				//Se lee la siguiente cadena que ya es un alumno
				cadenaLeida =archivoLectura.readLine();
				/* 
				 * Mientras haya cadenas en el archivo:
				 */
				while(cadenaLeida !=null){
					
					/*
					 * StringTokenizer permite separa una cadena en base a un
					 * separador, en este caso una "," que es lo que se tiene en 
					 * el archivo
					 */
					StringTokenizer st =new StringTokenizer(cadenaLeida,",");
					
					Alumno alumno =new Alumno();
					/*Se van tomando los tokens de acuerdo al orden en el que 
					 * se encuentran en el archivo
					 */
					alumno.setMatricula(st.nextToken());
					alumno.setPrimerApellido(st.nextToken());
					alumno.setSegundoApellido(st.nextToken());
					alumno.setNombre(st.nextToken());
					
					/*
					 * Se van agergando al arreglo
					 */
					arregloAlumnos[i]=alumno;
					i++;
					
					//Se lee la siguiente l�nea
					cadenaLeida =archivoLectura.readLine();
					
					}
				
				//Se cierra el archivo
				archivoLectura.close();
				
				/*
				 * Excepciones necesarias para el manejo de archivos
				 */
				}catch(FileNotFoundException e){
					System.out.println("No se pudo encontrar el archivo");
					e.printStackTrace();
					}catch(IOException e){
						System.out.println("No se pudo leer del archivo");e.printStackTrace();
						}
			
			return arregloAlumnos;
			
			}
	
}
