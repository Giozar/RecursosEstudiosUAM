import java.util.Scanner;

public class Principal {
	
public static void main(String args[]) {
		
		Procesar procesar = new Procesar();
		BusquedaBinaria bb = new BusquedaBinaria();
		
		
		Alumno [] arregloAlumnos = procesar.llenarArreglAlumno("alumnos.txt");
		
		System.out.println("Los alumnos son:");
		
		for(int i=0;i<arregloAlumnos.length;i++) {
			System.out.println(arregloAlumnos[i].toString());
		}
		
		String mat;
		Scanner lectura = new Scanner(System.in);
        
       System.out.print("\nIngresa la matr�cula del alumno a buscar: ");
       mat = lectura.nextLine();
		System.out.println(bb.busquedaBinaria(arregloAlumnos, mat));
     
	}

}
