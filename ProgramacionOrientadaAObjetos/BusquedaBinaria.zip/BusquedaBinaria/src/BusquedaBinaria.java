
public class BusquedaBinaria {
	
	public BusquedaBinaria() {
		
	}
	
	public boolean busquedaBinaria(Alumno a[], String buscado) {
		int primero = 0;
		int ultimo = a.length-1;
		int medio=0;
		boolean encontrado= false;
		
		while(primero <=ultimo && !encontrado) {
			medio = primero+ (ultimo-primero)/2;
			
			int valor = a[medio].getMatricula().compareTo(buscado);
			if(valor == 0) {
				
				encontrado = true;
			}else if(valor>0) {
				
				ultimo = medio-1;
			}else{
				
				primero = medio+1;
			}
		}
		if(encontrado == true ){
			System.out.println("\nEl Alumno existe");
			System.out.println("**Datos: "+a[medio].toString());
		}else {
			System.out.println("El alumno no existe");
		}
		return encontrado;
	}

}
