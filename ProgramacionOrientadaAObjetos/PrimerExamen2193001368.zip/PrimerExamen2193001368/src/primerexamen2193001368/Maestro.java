/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package primerexamen2193001368;

/**
 *
 * @author giova
 */
public class Maestro extends Persona {
    private String numEco;
    public Maestro(String nombre, String ocupacion, int edad, String genero, String numEco) {
        super(nombre, ocupacion, edad, genero);
        this.numEco = numEco;
    }

    public String getNumEco() {
        return numEco;
    }

    public void setNumEco(String numEco) {
        this.numEco = numEco;
    }

    @Override
    public String toString() {
        return super.toString() + " Maestro" + "numEco = " + numEco;
    }
    
    
    
}
