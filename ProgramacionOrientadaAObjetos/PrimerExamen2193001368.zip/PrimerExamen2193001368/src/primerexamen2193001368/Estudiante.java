/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package primerexamen2193001368;

/**
 *
 * @author giova
 */
public class Estudiante extends Persona {
    private String matricula;
    public Estudiante(String nombre, String ocupacion, int edad, String genero, String matricula) {
        super(nombre, ocupacion, edad, genero);
        this.matricula = matricula;
    }

    public String getMatricula() {
        return matricula;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }    

    @Override
    public String toString() {
        return super.toString() + " Estudiante" + "matricula = " + matricula;
    }
    
    
  
}
