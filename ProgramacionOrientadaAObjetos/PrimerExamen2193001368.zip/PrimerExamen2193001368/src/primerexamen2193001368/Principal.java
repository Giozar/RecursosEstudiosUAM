/*
    Primer Examen
MANUEL GIOVANNI CORTAZAR DE LA CRUZ
Matricula: 2193001368
 */
package primerexamen2193001368;

/**
 *
 * @author giova
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Persona aula[] = new Persona[5];
        
        aula[0] = new Maestro("Rubi Dorantes Flores","Docente Academico",32,"femenino","987654");
        aula[1] = new Maestro("Ruben Aguirre","Ayudante(Docente Academico)",28,"femenino","789456");
        aula[2] = new Estudiante("Ramon valdes urtiz","Estudiante",13,"femenino","23457");
        aula[3] = new Estudiante("Carlos villagran","Estudiante",14,"masculino","23458");
        aula[4] = new Estudiante("Maria Antonieta De Las Nieves","Estudiante",14,"masculino","23459");
        
        System.out.println("Personas en el aula de clases: ");
        System.out.println();
        
        for (int i = 0; i < aula.length; i++) {
            
            System.out.println(aula[i].toString());
            System.out.println();
        }
    }
    
}
